import { Personality } from "./Personality";

class Employees extends Personality
{
    
}